<?php 
	//connection
	require "connection.php";



if (is_logged_in()) {
	# code...
		//include the header

		require "header1.php";
?>

<section height="auto">
	<div class="container works clearfix">
		<div class="row">
			
				<div class="col-md-5 col-sm-5 col-xs-12 text-center pull-center wow fadeInUp animated" id="sign">
						<a name="signup"></a>
							<h3 class="whiten">Add a new greenhouse <i class="fa fa-sign-in"></i></h3>
							<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
							

							<!-- Signup form-->
							<form class="text-center" method="POST" enctype="multipart/form-data" action="./index.php">

								<input type="text" required id="nm" name="uname" class="form-control" onkeyup="strip1('nm');" placeholder="Name. e.g. Serikali Tafadhali" title="Well, here is where you tell us your name."><br>

								<input type="email" required name="email" id="im" title="You have an email, don't you?" class="form-control" onkeyup="strip3('im')" placeholder="Email. e.g. example@gmail.com">
								<br>

								<input type="text" required name="phone" id="pn" title="add your phone number" class="form-control" onkeyup="strip2('pn',13);" placeholder="phone. e.g. 254700112233"><br>

								<input type="password" required title="Now type your secret password" name="pass0" class="form-control" placeholder="Enter password"><br>

								<input type="password" required name="pass1" title="Re-enter the password" class="form-control" placeholder="Re-enter password"><br>

								<input type="submit" name="signU" class=" btn btn-info pull-center" value="Add">
							</form>
						</div>

			</div>
		</div>
	</div>
	</section>

<?php
//inculde the footer
		require "footer0.php";
	}
	else
	{
		header("location:index.php");
	}

?>