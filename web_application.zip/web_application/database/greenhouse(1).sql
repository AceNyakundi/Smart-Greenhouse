-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 02, 2017 at 06:21 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `greenhouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `f_name` varchar(200) NOT NULL,
  `f_email` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `greenhouse`
--

CREATE TABLE `greenhouse` (
  `owner` varchar(200) NOT NULL,
  `GSMNo` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `humstat`
--

CREATE TABLE `humstat` (
  `humidity` float NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `ref` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `humstat`
--

INSERT INTO `humstat` (`humidity`, `date`, `time`, `ref`) VALUES
(40, '2017-09-29', '09:53:22', 14),
(50, '2017-09-29', '09:53:49', 15),
(66, '2017-09-29', '09:56:04', 16),
(71, '2017-09-29', '09:56:15', 17),
(65, '2017-09-29', '09:56:27', 18),
(50, '2017-09-29', '10:22:48', 19),
(0, '2017-09-29', '10:23:29', 20),
(12, '2017-09-29', '10:24:19', 21),
(50, '2017-10-02', '10:46:35', 23),
(50, '2017-10-02', '10:46:43', 24),
(56, '2017-10-02', '10:47:03', 25),
(24, '2017-10-02', '10:47:30', 26),
(12, '2017-09-29', '10:47:50', 22),
(55, '2017-09-28', '13:31:34', 1),
(54, '2017-09-28', '13:55:44', 2),
(57, '2017-09-28', '13:58:17', 3),
(44, '2017-09-28', '22:54:02', 4),
(40, '2017-09-28', '22:55:31', 5),
(51, '2017-09-28', '22:56:27', 6),
(55, '2017-09-28', '22:59:05', 7),
(53, '2017-09-28', '22:59:18', 8),
(54, '2017-09-28', '22:59:46', 9),
(58, '2017-09-28', '23:00:29', 10),
(56, '2017-09-28', '23:00:52', 11),
(55, '2017-09-28', '23:05:17', 12),
(30, '2017-09-28', '23:08:52', 13);

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE `stats` (
  `GSMNo` int(12) NOT NULL,
  `temp` float NOT NULL,
  `hum` float NOT NULL,
  `moisture` int(6) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tempStats`
--

CREATE TABLE `tempStats` (
  `temperature` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `ref` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tempStats`
--

INSERT INTO `tempStats` (`temperature`, `date`, `time`, `ref`) VALUES
(20, '2017-09-29', '09:53:22', 14),
(21, '2017-09-29', '09:53:49', 15),
(23, '2017-09-29', '09:56:04', 16),
(30, '2017-09-29', '09:56:15', 17),
(25, '2017-09-29', '09:56:27', 18),
(21, '2017-09-29', '10:22:48', 19),
(40, '2017-09-29', '10:23:29', 20),
(38, '2017-09-29', '10:24:19', 21),
(20, '2017-10-02', '10:46:34', 23),
(22, '2017-10-02', '10:46:43', 24),
(25, '2017-10-02', '10:47:03', 25),
(23, '2017-10-02', '10:47:30', 26),
(38, '2017-09-29', '10:47:50', 22),
(25, '2017-09-28', '13:30:38', 1),
(20, '2017-09-28', '13:55:44', 2),
(23, '2017-09-28', '13:58:17', 3),
(25, '2017-09-28', '22:54:02', 4),
(20, '2017-09-28', '22:55:31', 5),
(28, '2017-09-28', '22:56:26', 6),
(21, '2017-09-28', '22:59:05', 7),
(22, '2017-09-28', '22:59:18', 8),
(26, '2017-09-28', '22:59:46', 9),
(24, '2017-09-28', '23:00:29', 10),
(28, '2017-09-28', '23:00:52', 11),
(26, '2017-09-28', '23:05:17', 12),
(16, '2017-09-28', '23:08:52', 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`f_email`);

--
-- Indexes for table `greenhouse`
--
ALTER TABLE `greenhouse`
  ADD PRIMARY KEY (`GSMNo`);

--
-- Indexes for table `humstat`
--
ALTER TABLE `humstat`
  ADD PRIMARY KEY (`time`),
  ADD UNIQUE KEY `ref` (`ref`);

--
-- Indexes for table `tempStats`
--
ALTER TABLE `tempStats`
  ADD PRIMARY KEY (`time`),
  ADD UNIQUE KEY `ref` (`ref`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `humstat`
--
ALTER TABLE `humstat`
  MODIFY `ref` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `tempStats`
--
ALTER TABLE `tempStats`
  MODIFY `ref` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
