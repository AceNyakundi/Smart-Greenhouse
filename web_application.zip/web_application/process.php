<?php 
	//connection
	require "connection.php";




	$errors= " ";

	if (isset($_GET['state'])) {
		
		$marker=$_GET['state'];

		switch($marker)
		{
			case 1: $errors="<script type='text/javascript'> alert('success!'); </script>"; break;
			case 2: $errors="<script 'text/javascript'> alert('failed!'); </script>"; break;
		} 
	}

	if (isset($_POST["Subm"])) {
		//collect data
		$tempRead=uncrack($_POST["temp"]);
		$humRead=uncrack($_POST["hum"]);
		//confirm that entered data is numeric
				//insert
			$sqt="INSERT into `tempStats` (`temperature`,`date`,`time`) 
			values('$tempRead',CURDATE(),CURTIME())";
			$sqh="INSERT into `humstat` (`humidity`,`date`,`time`) values('$humRead',CURDATE(),CURTIME())";


				//start when status is true and make it false if it fails
			$status=true;
				//disable autocommit
			$mysqli->autocommit(FALSE);
				//try each individually
			$mysqli->query($sqt)?null: $status=false;//update temperature
			$mysqli->query($sqh)?null: $status=false;//update humidity

			if($status)
			{
			 $mysqli->commit(); //header("location:process.php?state=1"); //report success
			}
			else
			{

				$mysqli->rollback(); //header("location:process.php?state=2"); //report error
			}
	}


		
		//include the header
		require "header0.php";
?>

<section height="auto">
	<div class="container works clearfix">
		<div class="row">
		<!-- report errors if any -->
		<div>
			<?php echo $errors;?>
		</div>

		<!-- display form  -->
		<div class="panel panel-default col-md-4 login-frm center pull-right w3-card-8">
		<div class="panel panel-heading">
			<h2 class="text-center">Enter some dummy data for temperature &amp; humidity.</h2>
		</div>
		<div class="panel panel-body">
			<form class="form text-center" method="post" action="process.php">
			<div class="form-group">
			<label for="temp">Temperature (in celcius): </label>
				<input placeholder="Enter temperature (*C)" autofocus required type="text" name="temp" id="temp" class="form-control text-center">
			</div>
			<div class="form-group">
			<label for="hum">Humidity (%)</label>
				<input placeholder="Enter humidity" required type="text" name="hum" id="hum" class="form-control text-center">
			</div>

			<div class="form-group">
				<input type="submit" value="Send..." name="Subm" class="form-control btn btn-info">
			</div>
				
			</form>
			
		</div>
		</div>
	</div>
	</section>

<?php
//inculde the footer
		require "footer0.php";

?>