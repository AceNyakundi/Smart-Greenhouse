<?php 

require "connection.php";

	require_once ('jpgraph/src/jpgraph.php');
	require_once ('jpgraph/src/jpgraph_line.php');


//require connection

	# code...


	# when not set, assume today
if (!isset($today)) {
	$today=date('y-m-d');
}

$today=date('y-m-d');

//sql statement
$sqtemp="SELECT `temperature`, `time` from `tempStats` where `date`='$today'  order by `ref` desc limit 11";

//$sqhum="SELECT `humidity`, `time` from `humstat` where `date`='$today' order by `time` asc limit 10";

//resultsets for temperature as global
global $temprec,$timerec,$tcount;
$temprec = array(); $timerec=array();


$qq=mysqli_query($conn,$sqtemp);

while ($row=mysqli_fetch_array($qq,MYSQLI_BOTH)) {
	//add to array
	array_push($temprec, $row['temperature']);
	array_push($timerec, $row['time']);
	//$tcount=$row['tcount'];
}

$num=count($temprec);


$temprec=array_reverse($temprec); //reverse array values


if($num>=1)
{
	$count_stamp=$timerec[0];
	$initial=$timerec[$num-1];
	$val=count($temprec);

	$datay = $temprec;//temperature readings in an array from DB

	$graph = new Graph(660,590);
	$graph->clearTheme();
	$graph->img->SetMargin(40,40,40,40);


	$graph->img->SetAntiAliasing();
	$graph->SetScale("intint");
	$graph->SetShadow();
	$graph->title->Set("$val Temperature readings on $today as from $initial to $count_stamp");
	$graph->title->SetFont(FF_FONT1,FS_BOLD);

	$graph->xaxis->title->Set("Time in seconds (s)");


	$graph->yaxis->title->Set("Temperature in Celcius (*C)");
	// Add 10% grace to top and bottom of plot
	$graph->yscale->SetGrace(10,10);

	$p1 = new LinePlot($datay);
	$p1->mark->SetType(MARK_FILLEDCIRCLE);
	$p1->mark->SetFillColor("red");
	$p1->mark->SetWidth(4);
	$p1->SetColor("blue");
	$p1->SetCenter();
	$p1->SetFillColor('orange@0.5');
	$graph->Add($p1);

	$graph->Stroke();
}
else
{
	echo "No $tcount data has been received for the date $today. Possible reasons for this occurance are:
		<br> 1. Your device lacks power (possibly a prolonged black-out).
		<br> 2. You have not subscribed/bought data bundles for your device.
		<br> 3. Your device mulfunctioned.
		<br> <h3> If this problem persists. Kindly <a href='#'>contact us</a>. 
	";
}



?>
