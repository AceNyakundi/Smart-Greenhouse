<?php
//connection and default header 
require "connection.php";
//global errors variable stores and reports page-related errors. defined in errors.php



if (is_logged_in()) {
	header("location:home.php");
}
else
{
$errors="";

//handles page-related errors
//require_once "./php/ext/errors.php";

//basic header. modify this at end of programming the system
/***==================================================***
			user has requested to login
 ***==================================================***
*/
if (isset($_POST["logU"])) {
	#collect data
	$email=uncrack($_POST["email"]);
	$password=uncrack($_POST["pass0"]);

	if (isset($email)&&isset($password)) {
		$sq0="select f_email, f_name, password from farmer where f_email='$email' and password=SHA('$password')";
		$rec=mysqli_fetch_array(mysqli_query($conn,$sq0));
		if (count($rec)>0) {

			$rec=mysqli_fetch_array(mysqli_query($conn,$sq0));
			$nm=$rec["f_name"];

			//set cookies then direct user to homepage
			setcookie("Name",$nm,time()+86400*30,"/","",0);
			setcookie("Mail",$email,time()+86400*30,"/","",0);
			
			
			header("location:./home.php");
		}
		else
		{
			$errors="<div class='alert alert-warning fade in text-center'> <strong>Invalid login details</strong> <br> 
					It seems you entered invalid login details <br>
				<a href=\"index.php\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\"> &times;</a>
				</div>";
		}
	}
	else
	{
		$errors="<div class='alert alert-warning fade in text-center'> <strong>You missed to enter some required fields</strong> <br> 
					Please try and fill all the fields and try again. <br>
				<a href=\"index.php\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\"> &times;</a>
				</div>";
	}

}



if (isset($_POST['signU'])) {
	# collect data
	$name=is_username($_POST['uname']);
	$email=uncrack($_POST["email"]);
	$pass0=uncrack($_POST["pass0"]);
	$pass1=uncrack($_POST["pass1"]);

	if ($pass0===$pass1) {
		$sqn="INSERT INTO farmer (f_name, f_email,password) values('$name','$email',SHA('$pass1'))";
		if (mysqli_query($conn,$sqn)) {
			$errors="<div class='alert alert-success fade in text-center'> <strong>Great</strong> <br> 
					Registration successful <br>
				<a href=\"index.php\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\"> &times;</a>
				</div>";
		}
		else
		{
			$errors="<div class='alert alert-warning fade in text-center'> <strong>Sorry visitor</strong> <br> 
					There is a connection problem. System failed to submit <br>
				<a href=\"index.php\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\"> &times;</a>
				</div>";
		}
	}
	else
	{
		$errors="<div class='alert alert-warning fade in text-center'> <strong>Sorry visitor</strong> <br> 
					Theused passwords do not match <br>
				<a href=\"index.php\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\"> &times;</a>
				</div>";
	}
	
}

require "header0.php";
?>


  
		
		<section id="" class="">
			<div id="carousel-example-generic" class="carousel slide slider-cover" data-ride="carousel">
				<!-- I opted to use a fixed header image instead of slider -->
				<div class="row">
						<div><?php echo $errors; ?></div>
					<div class="slider-mage slide-custom col-md-6">
					
					<img src="./img/index.jpeg" class="img img-responsive img-head" alt="our brand image">
					</div>

					<div class="slider-content class-md-6">
						<h1 data-wow-duration="700ms" data-wow-delay="500ms" class="wow bounceInDown animated">
						Welcome to SGP - <i>Smart Greenhouse Management System (SGP)</i>
						</h1>
						<p>Some explanation about SGP <br /></p>
						
					</div>
				</div>

					
				
			</div>
		</section>
		

        <!--I throw in something about us -->
   




		<section id="facts" class="facts">
			<div class="parallax-overlay-two">
				<div class="container">
					<div class="row number-counters">
						
						<div class="sec-title text-center mb50 wow rubberBand animated" data-wow-duration="1000ms">
						 
							<h2 class="whiten">Let's get started</h2>
							<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
						</div>
						
						
						<div class="col-md-5 col-sm-5 col-xs-12 text-center pull-center wow fadeInUp animated" id="sign">
						<a name="signup"></a>
							<h3 class="whiten">Farmer Sign up <i class="fa fa-sign-in"></i></h3>
							<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
							

							<!-- Signup form-->
							<form class="text-center" method="POST" enctype="multipart/form-data" action="./index.php">

								<input type="text" required id="nm" name="uname" class="form-control" onkeyup="strip1('nm');" placeholder="Name. e.g. Serikali Tafadhali" title="Well, here is where you tell us your name."><br>

								<input type="email" required name="email" id="im" title="You have an email, don't you?" class="form-control" onkeyup="strip3('im')" placeholder="Email. e.g. example@gmail.com">
								<br>

								<!--
								<input type="text" required name="phone" id="pn" title="add your phone number" class="form-control" onkeyup="strip2('pn',13);" placeholder="phone. e.g. 254700112233"><br> -->

								<input type="password" required title="Now type your secret password" name="pass0" class="form-control" placeholder="Enter password"><br>

								<input type="password" required name="pass1" title="Re-enter the password" class="form-control" placeholder="Re-enter password"><br>

								<input type="submit" name="signU" class=" btn btn-info pull-center" value="Sign Up">
							</form>
						</div>

						<div class="col-md-4 col-sm-4 col-xs-12 text-center wow fadeInUp animated pull-right" id="logg">
						<a name="login"></a>
							<h3 class="whiten">User Login <i class="fa fa-user fa-lg"></i></h3>
							<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
							<form method="POST" action="./index.php">
								<input type="email" required name="email" class="form-control" placeholder="Email. e.g. example@gmail.com"><br>
								<input type="password" required name="pass0" class="form-control" placeholder="Enter password"><br>
								<input type="submit" name="logU" class="btn btn-info pull-center" value="Login...">
							</form>
						</div>

						<!-- end first count item -->
				
					</div>
				</div>
			</div>
		</section>
		
        <!--
        			End Our Works
        ==================================== -->
		
		
			
		
  
		
		
		<footer id="footer" class="footer">
			<div class="container">
				
				<div class="row">
					<div class="col-md-12">
						
					</div>
				</div>
			</div>
		</footer>
		
		<a href="javascript:void(0);" id="back-top"><i class="fa fa-angle-up fa-3x"></i></a>

		<!-- Essential jQuery Plugins
		================================================== -->
		<!-- Main jQuery -->
        <script src="js/jquery-1.11.1.min.js"></script>
        <!-- Main javascript modified for makers hub-->
        <script src="js/makers.js"></script>
		<!-- Single Page Nav -->
        <script src="js/jquery.singlePageNav.min.js"></script>
		<!-- Twitter Bootstrap -->
        <script src="js/bootstrap.min.js"></script>
		<!-- jquery.fancybox.pack -->
        <script src="js/jquery.fancybox.pack.js"></script>
		<!-- jquery.mixitup.min -->
        <script src="js/jquery.mixitup.min.js"></script>
		<!-- jquery.parallax -->
        <script src="js/jquery.parallax-1.1.3.js"></script>
		<!-- jquery.countTo -->
        <script src="js/jquery-countTo.js"></script>
		<!-- jquery.appear -->
        <script src="js/jquery.appear.js"></script>
		<!-- Contact form validation -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.32/jquery.form.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.1/jquery.validate.min.js"></script>
		<!-- Google Map -->
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&key=AIzaSyApI3pCxUiWNyIy_884pMmw1LTJ4gAbRiw"></script>
		<!-- jquery easing -->
        <script src="js/jquery.easing.min.js"></script>
		<!-- jquery easing -->
        <script src="js/wow.min.js"></script>
		<script>
		//on-page jquery animations JS and asyncronous JS
		function strip1(e) {
		var Textf=document.getElementById(e);
		var repl= /[^a-z 0-9]/gi;
		Textf.value=Textf.value.replace(repl,"");	
		};

		//strip letters and special characters for phone num.
		function strip2(e,len){
		var text0=document.getElementById(e).value;
		var text1=document.getElementById(e);
		if (text0.length<len) {
		var Textf=document.getElementById(e);
		var repl= /[^0-9]/gi;
		Textf.value=Textf.value.replace(repl,"");
		}
		else
		{
			text1.value = text0.substr(0,len);
			//slice();
		}
		};

				//strip letters and special characters in an email.
function strip3(e) {
		var Textf=document.getElementById(e);
		var repl= /[^0-9a-z.@_]/gi;
		Textf.value=Textf.value.replace(repl,"");	
		};

			var wow = new WOW ({
				boxClass:     'wow',      // animated element css class (default is wow)
				animateClass: 'animated', // animation css class (default is animated)
				offset:       120,          // distance to the element when triggering the animation (default is 0)
				mobile:       false,       // trigger animations on mobile devices (default is true)
				live:         true        // act on asynchronously loaded content (default is true)
			  }
			);
			wow.init();
		</script> 
		<!-- Custom Functions -->
        <script src="js/custom.js"></script>
		
	<script type="text/javascript">

	


			
		</script>
		</div>
    </body>
</html>
<?php

}

?>