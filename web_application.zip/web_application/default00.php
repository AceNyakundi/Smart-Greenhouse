<?php 
	//connection
	require "connection.php";




		//include the header

		require "header1.php";
?>

<section height="auto">
	<div class="container works clearfix">
		<div class="row">
			
	

			</div>
		</div>
	</div>
	</section>

<?php
//inculde the footer
		require "footer0.php";

?>