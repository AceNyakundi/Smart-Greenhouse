<?php 
	//connection
	require "connection.php";
	
	$errors= " ";


if (is_logged_in()) {
	# code...

		//include the header
		require "header1.php";
?>

<section height="auto" onload="showTempGraph()">
	<div class="container works clearfix">
		<div class="row">
		<!-- report errors if any -->
		<div>
			<?php echo $errors; ?>
		</div>


		<div id="">
		<div class="sec-title text-center mb50 wow rubberBand animated" data-wow-duration="1000ms">
						 
				<h2>Recent Greenhouse Temperature Readings</h2>
				<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
		</div>

		<div id="tempgraph" class="center-div">
			 <iframe src="./templinegraph.php" width="700" height="600">
			 	
			 </iframe>
		</div>
		</div>

		<div class="devider"><i class=""></i></div> 

		<div id="">
		<div class="sec-title text-center mb50 wow rubberBand animated" data-wow-duration="1000ms">
						 
				<h2>Recent Greenhouse Humidity Readings</h2>
				<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
		</div>

		<div id="tempgraph" class="center-div">
			 <iframe src="./humlinegraph.php" width="700" height="600">
			 	
			 </iframe>
		</div>
		</div>


	</div>
	</section>

<?php
//inculde the footer
		require "footer0.php";
	}
	else
	{
		header("location:index.php");
	}

?>