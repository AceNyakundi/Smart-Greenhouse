<?php

//end cookies and logout user
			setcookie("Name",$uname,time()-86400*31,"/","",0);
			setcookie("Mail",$mail,time()-86400*31,"/","",0);
			//setcookie("Type",$mail,time()-86400*31,"/","",0);
			//direct user to index page.
			header("location:index.php");
?>